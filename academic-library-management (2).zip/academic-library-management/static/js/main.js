// Main JavaScript for Academic Library Management System

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Search functionality enhancements
    const searchInput = document.querySelector('input[name="q"]');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(function() {
            // In a real application, this could trigger live search
            console.log('Search query:', this.value);
        }, 300));
    }

    // Form validation
    var forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Book card interactions
    const bookCards = document.querySelectorAll('.book-card');
    bookCards.forEach(function(card) {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Dashboard animations
    animateCounters();
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl+F for search
        if (e.ctrlKey && e.key === 'f') {
            e.preventDefault();
            const searchInput = document.querySelector('input[name="q"]');
            if (searchInput) {
                searchInput.focus();
            }
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.modal.show');
            if (openModal) {
                const modal = bootstrap.Modal.getInstance(openModal);
                modal.hide();
            }
        }
    });
});

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function animateCounters() {
    const counters = document.querySelectorAll('.stat-number, .metric-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.textContent);
        if (isNaN(target)) return;
        
        const increment = target / 100;
        let current = 0;
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                counter.textContent = target;
                clearInterval(timer);
            } else {
                counter.textContent = Math.floor(current);
            }
        }, 20);
    });
}

// Search enhancements
function highlightSearchResults(query) {
    if (!query) return;
    
    const results = document.querySelectorAll('.search-result');
    results.forEach(result => {
        const title = result.querySelector('.card-title');
        const author = result.querySelector('.card-text');
        
        if (title) {
            title.innerHTML = highlightText(title.textContent, query);
        }
        if (author) {
            author.innerHTML = highlightText(author.textContent, query);
        }
    });
}

function highlightText(text, query) {
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
}

// Form helpers
function validateISBN(isbn) {
    // Remove any non-digit characters
    isbn = isbn.replace(/\D/g, '');
    
    // Check if it's 13 digits
    if (isbn.length !== 13) {
        return false;
    }
    
    // Calculate checksum for ISBN-13
    let sum = 0;
    for (let i = 0; i < 12; i++) {
        sum += parseInt(isbn[i]) * (i % 2 === 0 ? 1 : 3);
    }
    
    const checkDigit = (10 - (sum % 10)) % 10;
    return checkDigit === parseInt(isbn[12]);
}

// Dashboard helpers
function updateDashboardStats() {
    // In a real application, this would fetch updated stats via AJAX
    console.log('Updating dashboard statistics...');
}

// Book management functions
function quickCheckout(bookId) {
    const userId = prompt('Enter User ID for checkout:');
    if (userId && !isNaN(userId)) {
        // Create a form and submit it
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/checkout';
        
        const userInput = document.createElement('input');
        userInput.type = 'hidden';
        userInput.name = 'user_id';
        userInput.value = userId;
        
        const bookInput = document.createElement('input');
        bookInput.type = 'hidden';
        bookInput.name = 'book_id';
        bookInput.value = bookId;
        
        form.appendChild(userInput);
        form.appendChild(bookInput);
        document.body.appendChild(form);
        form.submit();
    } else if (userId !== null) {
        alert('Please enter a valid User ID');
    }
}

// Report functions
function exportReport() {
    // In a production environment, this would trigger a server-side export
    alert('Export functionality would generate a downloadable CSV/Excel file.');
}

function printReport() {
    window.print();
}

// Notification system
function showNotification(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            const alert = new bootstrap.Alert(alertDiv);
            alert.close();
        }, 5000);
    }
}

// Loading states
function showLoading(element) {
    element.classList.add('loading');
    const spinner = document.createElement('span');
    spinner.className = 'spinner-border spinner-border-sm me-2';
    element.insertBefore(spinner, element.firstChild);
}

function hideLoading(element) {
    element.classList.remove('loading');
    const spinner = element.querySelector('.spinner-border');
    if (spinner) {
        spinner.remove();
    }
}

// AJAX helpers for future enhancements
function makeRequest(url, method = 'GET', data = null) {
    return fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: data ? JSON.stringify(data) : null
    }).then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.json();
    });
}

// Error handling
window.addEventListener('error', function(e) {
    console.error('JavaScript error:', e.error);
    showNotification('An error occurred. Please try again.', 'danger');
});

// Performance monitoring (basic)
window.addEventListener('load', function() {
    const loadTime = performance.now();
    console.log(`Page loaded in ${loadTime.toFixed(2)}ms`);
});

// Accessibility enhancements
function enhanceAccessibility() {
    // Add ARIA labels to buttons without text
    const iconButtons = document.querySelectorAll('button > i:only-child');
    iconButtons.forEach(button => {
        const parent = button.parentElement;
        if (!parent.getAttribute('aria-label') && !parent.getAttribute('title')) {
            const icon = button.className;
            if (icon.includes('fa-search')) parent.setAttribute('aria-label', 'Search');
            if (icon.includes('fa-edit')) parent.setAttribute('aria-label', 'Edit');
            if (icon.includes('fa-delete')) parent.setAttribute('aria-label', 'Delete');
            if (icon.includes('fa-view')) parent.setAttribute('aria-label', 'View');
        }
    });
    
    // Add focus indicators for keyboard navigation
    const focusableElements = document.querySelectorAll('a, button, input, textarea, select');
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid #007bff';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
}

// Initialize accessibility enhancements
enhanceAccessibility(); 