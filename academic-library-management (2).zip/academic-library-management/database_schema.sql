-- Academic Library Management System Database Schema
-- This schema implements the Entity-Relationship model for the library management system
-- Created: 2024
-- Database: SQLite (can be adapted for PostgreSQL/MySQL)

-- ==============================================
-- Table: User
-- Stores information about all system users (Students, Librarians, Administrators)
-- ==============================================
CREATE TABLE user (
    userID INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(200) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'student',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT chk_role CHECK (role IN ('student', 'librarian', 'admin')),
    CONSTRAINT chk_email_format CHECK (email LIKE '%@%')
);

-- ==============================================
-- Table: Book
-- Stores information about books in the library catalog
-- ==============================================
CREATE TABLE book (
    bookID INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(100) NOT NULL,
    ISBN VARCHAR(13) UNIQUE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'available',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    CONSTRAINT chk_status CHECK (status IN ('available', 'checked_out', 'reserved', 'damaged', 'lost')),
    CONSTRAINT chk_isbn_length CHECK (LENGTH(ISBN) = 13),
    CONSTRAINT chk_isbn_numeric CHECK (ISBN GLOB '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

-- ==============================================
-- Table: Transaction
-- Stores information about book borrowing transactions
-- ==============================================
CREATE TABLE transaction (
    transactionID INTEGER PRIMARY KEY AUTOINCREMENT,
    userID INTEGER NOT NULL,
    bookID INTEGER NOT NULL,
    borrowDate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    returnDate DATETIME NULL,
    dueDate DATETIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (userID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY (bookID) REFERENCES book(bookID) ON DELETE CASCADE,
    
    -- Constraints
    CONSTRAINT chk_transaction_status CHECK (status IN ('active', 'completed', 'overdue')),
    CONSTRAINT chk_borrow_before_due CHECK (borrowDate <= dueDate),
    CONSTRAINT chk_return_after_borrow CHECK (returnDate IS NULL OR returnDate >= borrowDate)
);

-- ==============================================
-- Table: Fine
-- Stores information about fines imposed on users
-- ==============================================
CREATE TABLE fine (
    fineID INTEGER PRIMARY KEY AUTOINCREMENT,
    userID INTEGER NOT NULL,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status VARCHAR(20) NOT NULL DEFAULT 'unpaid',
    reason VARCHAR(200),
    date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_paid DATETIME NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (userID) REFERENCES user(userID) ON DELETE CASCADE,
    
    -- Constraints
    CONSTRAINT chk_fine_status CHECK (status IN ('paid', 'unpaid', 'waived')),
    CONSTRAINT chk_fine_amount CHECK (amount >= 0),
    CONSTRAINT chk_payment_date CHECK (date_paid IS NULL OR date_paid >= date_created)
);

-- ==============================================
-- Table: Reservation
-- Stores information about book reservations
-- ==============================================
CREATE TABLE reservation (
    reservationID INTEGER PRIMARY KEY AUTOINCREMENT,
    userID INTEGER NOT NULL,
    bookID INTEGER NOT NULL,
    date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    expiry_date DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Foreign key constraints
    FOREIGN KEY (userID) REFERENCES user(userID) ON DELETE CASCADE,
    FOREIGN KEY (bookID) REFERENCES book(bookID) ON DELETE CASCADE,
    
    -- Constraints
    CONSTRAINT chk_reservation_status CHECK (status IN ('active', 'fulfilled', 'cancelled', 'expired')),
    CONSTRAINT chk_expiry_after_creation CHECK (expiry_date IS NULL OR expiry_date > date),
    
    -- Unique constraint to prevent duplicate active reservations
    CONSTRAINT unique_active_reservation UNIQUE (userID, bookID, status) 
    -- Note: This constraint may need adjustment based on business rules
);

-- ==============================================
-- INDEXES for Performance Optimization
-- ==============================================

-- User table indexes
CREATE INDEX idx_user_email ON user(email);
CREATE INDEX idx_user_role ON user(role);

-- Book table indexes
CREATE INDEX idx_book_isbn ON book(ISBN);
CREATE INDEX idx_book_status ON book(status);
CREATE INDEX idx_book_title ON book(title);
CREATE INDEX idx_book_author ON book(author);

-- Transaction table indexes
CREATE INDEX idx_transaction_user ON transaction(userID);
CREATE INDEX idx_transaction_book ON transaction(bookID);
CREATE INDEX idx_transaction_status ON transaction(status);
CREATE INDEX idx_transaction_due_date ON transaction(dueDate);
CREATE INDEX idx_transaction_borrow_date ON transaction(borrowDate);

-- Fine table indexes
CREATE INDEX idx_fine_user ON fine(userID);
CREATE INDEX idx_fine_status ON fine(status);
CREATE INDEX idx_fine_date_created ON fine(date_created);

-- Reservation table indexes
CREATE INDEX idx_reservation_user ON reservation(userID);
CREATE INDEX idx_reservation_book ON reservation(bookID);
CREATE INDEX idx_reservation_status ON reservation(status);
CREATE INDEX idx_reservation_date ON reservation(date);

-- ==============================================
-- VIEWS for Common Queries
-- ==============================================

-- View: Active Loans
CREATE VIEW active_loans AS
SELECT 
    t.transactionID,
    u.name as borrower_name,
    u.email as borrower_email,
    b.title,
    b.author,
    b.ISBN,
    t.borrowDate,
    t.dueDate,
    CASE 
        WHEN t.dueDate < CURRENT_TIMESTAMP THEN 'overdue'
        ELSE 'active'
    END as loan_status,
    CASE 
        WHEN t.dueDate < CURRENT_TIMESTAMP 
        THEN CAST((julianday(CURRENT_TIMESTAMP) - julianday(t.dueDate)) AS INTEGER)
        ELSE 0
    END as days_overdue
FROM transaction t
JOIN user u ON t.userID = u.userID
JOIN book b ON t.bookID = b.bookID
WHERE t.status = 'active';

-- View: Overdue Books
CREATE VIEW overdue_books AS
SELECT 
    t.transactionID,
    u.userID,
    u.name as borrower_name,
    u.email as borrower_email,
    b.bookID,
    b.title,
    b.author,
    t.borrowDate,
    t.dueDate,
    CAST((julianday(CURRENT_TIMESTAMP) - julianday(t.dueDate)) AS INTEGER) as days_overdue,
    CAST((julianday(CURRENT_TIMESTAMP) - julianday(t.dueDate)) AS INTEGER) * 1.0 as fine_amount
FROM transaction t
JOIN user u ON t.userID = u.userID
JOIN book b ON t.bookID = b.bookID
WHERE t.status = 'active' AND t.dueDate < CURRENT_TIMESTAMP;

-- View: Available Books
CREATE VIEW available_books AS
SELECT 
    bookID,
    title,
    author,
    ISBN,
    status
FROM book
WHERE status = 'available';

-- View: User Statistics
CREATE VIEW user_statistics AS
SELECT 
    u.userID,
    u.name,
    u.email,
    u.role,
    COUNT(DISTINCT t.transactionID) as total_transactions,
    COUNT(DISTINCT CASE WHEN t.status = 'active' THEN t.transactionID END) as active_loans,
    COUNT(DISTINCT r.reservationID) as active_reservations,
    COALESCE(SUM(CASE WHEN f.status = 'unpaid' THEN f.amount END), 0) as outstanding_fines
FROM user u
LEFT JOIN transaction t ON u.userID = t.userID
LEFT JOIN reservation r ON u.userID = r.userID AND r.status = 'active'
LEFT JOIN fine f ON u.userID = f.userID
GROUP BY u.userID, u.name, u.email, u.role;

-- ==============================================
-- TRIGGERS for Data Integrity and Automation
-- ==============================================

-- Trigger: Update book status when checked out
CREATE TRIGGER update_book_status_checkout
AFTER INSERT ON transaction
WHEN NEW.status = 'active'
BEGIN
    UPDATE book 
    SET status = 'checked_out', updated_at = CURRENT_TIMESTAMP
    WHERE bookID = NEW.bookID;
END;

-- Trigger: Update book status when returned
CREATE TRIGGER update_book_status_return
AFTER UPDATE ON transaction
WHEN OLD.status = 'active' AND NEW.status = 'completed'
BEGIN
    UPDATE book 
    SET status = 'available', updated_at = CURRENT_TIMESTAMP
    WHERE bookID = NEW.bookID;
END;

-- Trigger: Set due date automatically (14 days from borrow date)
CREATE TRIGGER set_due_date
AFTER INSERT ON transaction
WHEN NEW.dueDate IS NULL
BEGIN
    UPDATE transaction 
    SET dueDate = datetime(NEW.borrowDate, '+14 days')
    WHERE transactionID = NEW.transactionID;
END;

-- Trigger: Update updated_at timestamp
CREATE TRIGGER update_user_timestamp
AFTER UPDATE ON user
BEGIN
    UPDATE user SET updated_at = CURRENT_TIMESTAMP WHERE userID = NEW.userID;
END;

CREATE TRIGGER update_book_timestamp
AFTER UPDATE ON book
BEGIN
    UPDATE book SET updated_at = CURRENT_TIMESTAMP WHERE bookID = NEW.bookID;
END;

CREATE TRIGGER update_transaction_timestamp
AFTER UPDATE ON transaction
BEGIN
    UPDATE transaction SET updated_at = CURRENT_TIMESTAMP WHERE transactionID = NEW.transactionID;
END;

-- ==============================================
-- SAMPLE DATA INSERTION
-- ==============================================

-- Insert default administrator
INSERT INTO user (name, email, password, role) VALUES 
('System Administrator', 'admin@library.com', 'hashed_password_here', 'admin');

-- Insert sample librarian
INSERT INTO user (name, email, password, role) VALUES 
('John Librarian', 'librarian@library.com', 'hashed_password_here', 'librarian');

-- Insert sample books
INSERT INTO book (title, author, ISBN) VALUES 
('Introduction to Computer Science', 'John Smith', '9781234567890'),
('Database Systems', 'Jane Doe', '9781234567891'),
('Web Development Fundamentals', 'Bob Johnson', '9781234567892'),
('Software Engineering Principles', 'Alice Brown', '9781234567893'),
('Data Structures and Algorithms', 'Charlie Wilson', '9781234567894');

-- ==============================================
-- STORED PROCEDURES (Functions for SQLite)
-- Note: SQLite doesn't support stored procedures, but these would be 
-- implemented as application-level functions
-- ==============================================

/*
-- Function to calculate fine amount
CREATE FUNCTION calculate_fine(due_date DATE, return_date DATE DEFAULT CURRENT_DATE)
RETURNS DECIMAL(10,2)
BEGIN
    DECLARE days_overdue INT;
    DECLARE fine_per_day DECIMAL(10,2) DEFAULT 1.00;
    
    IF return_date <= due_date THEN
        RETURN 0.00;
    END IF;
    
    SET days_overdue = DATEDIFF(return_date, due_date);
    RETURN days_overdue * fine_per_day;
END;

-- Function to check if user can borrow books
CREATE FUNCTION can_user_borrow(user_id INT)
RETURNS BOOLEAN
BEGIN
    DECLARE overdue_count INT;
    DECLARE unpaid_fines DECIMAL(10,2);
    
    SELECT COUNT(*) INTO overdue_count
    FROM transaction t
    WHERE t.userID = user_id 
    AND t.status = 'active' 
    AND t.dueDate < CURRENT_TIMESTAMP;
    
    SELECT COALESCE(SUM(amount), 0) INTO unpaid_fines
    FROM fine f
    WHERE f.userID = user_id AND f.status = 'unpaid';
    
    IF overdue_count > 0 OR unpaid_fines > 50.00 THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
*/

-- ==============================================
-- DATABASE MAINTENANCE QUERIES
-- ==============================================

-- Query to find and update overdue transactions
-- UPDATE transaction SET status = 'overdue' 
-- WHERE status = 'active' AND dueDate < CURRENT_TIMESTAMP;

-- Query to clean up expired reservations
-- UPDATE reservation SET status = 'expired' 
-- WHERE status = 'active' AND expiry_date < CURRENT_TIMESTAMP;

-- Query to get database statistics
-- SELECT 
--     (SELECT COUNT(*) FROM user) as total_users,
--     (SELECT COUNT(*) FROM book) as total_books,
--     (SELECT COUNT(*) FROM transaction WHERE status = 'active') as active_loans,
--     (SELECT COUNT(*) FROM reservation WHERE status = 'active') as active_reservations,
--     (SELECT SUM(amount) FROM fine WHERE status = 'unpaid') as total_unpaid_fines;

-- ==============================================
-- BACKUP AND RECOVERY NOTES
-- ==============================================

-- For SQLite, backup can be done using:
-- .backup backup_filename.db

-- For production systems, consider:
-- 1. Regular automated backups
-- 2. Transaction log backups
-- 3. Point-in-time recovery capabilities
-- 4. Replication for high availability

-- ==============================================
-- SECURITY CONSIDERATIONS
-- ==============================================

-- 1. Password hashing: Use bcrypt or similar for password storage
-- 2. SQL Injection: Use parameterized queries
-- 3. Role-based access: Implement proper authorization checks
-- 4. Data validation: Validate all inputs at application level
-- 5. Audit logging: Consider adding audit trails for sensitive operations

-- ==============================================
-- PERFORMANCE OPTIMIZATION NOTES
-- ==============================================

-- 1. Regular ANALYZE to update statistics
-- 2. VACUUM to reclaim space and optimize database
-- 3. Consider partitioning for large datasets
-- 4. Monitor slow queries and add indexes as needed
-- 5. Archive old transaction data periodically 