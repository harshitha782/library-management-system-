#!/usr/bin/env python3
"""
Academic Library Management System - Startup Script

This script initializes and runs the Academic Library Management System.
It sets up the database, creates sample data, and starts the Flask development server.
"""

import os
import sys
from app import app, db, User, Book, generate_password_hash

def initialize_database():
    """Initialize the database with tables and sample data."""
    print("Initializing database...")
    
    # Create all tables
    db.create_all()
    
    # Check if admin user already exists
    admin = User.query.filter_by(email='admin@library.com').first()
    if admin:
        print("Database already initialized with sample data.")
        return
    
    print("Creating sample data...")
    
    # Create default admin user
    admin_user = User(
        name='System Administrator',
        email='admin@library.com',
        password=generate_password_hash('admin123'),
        role='admin'
    )
    db.session.add(admin_user)
    
    # Create sample librarian
    librarian = User(
        name='John Librarian',
        email='librarian@library.com',
        password=generate_password_hash('lib123'),
        role='librarian'
    )
    db.session.add(librarian)
    
    # Create sample student
    student = User(
        name='Jane Student',
        email='student@library.com',
        password=generate_password_hash('student123'),
        role='student'
    )
    db.session.add(student)
    
    # Create sample books
    sample_books = [
        Book(
            title='Python Programming: An Introduction to Computer Science',
            author='John Zelle',
            ISBN='9781590282755'
        ),
        Book(
            title='Clean Code: A Handbook of Agile Software Craftsmanship',
            author='Robert Martin',
            ISBN='9780132350884'
        ),
        Book(
            title='The Pragmatic Programmer',
            author='David Thomas, Andrew Hunt',
            ISBN='9780201616224'
        ),
        Book(
            title='Introduction to Algorithms',
            author='Thomas Cormen',
            ISBN='9780262033848'
        ),
        Book(
            title='Design Patterns: Elements of Reusable Object-Oriented Software',
            author='Gang of Four',
            ISBN='9780201633612'
        ),
        Book(
            title='Database System Concepts',
            author='Abraham Silberschatz',
            ISBN='9780078022159'
        ),
        Book(
            title='Computer Networks',
            author='Andrew Tanenbaum',
            ISBN='9780132126953'
        ),
        Book(
            title='Operating System Concepts',
            author='Abraham Silberschatz',
            ISBN='9781118063330'
        )
    ]
    
    for book in sample_books:
        db.session.add(book)
    
    # Commit all changes
    try:
        db.session.commit()
        print("Sample data created successfully!")
        print("\n" + "="*50)
        print("DEFAULT LOGIN CREDENTIALS:")
        print("="*50)
        print("Administrator:")
        print("  Email: admin@library.com")
        print("  Password: admin123")
        print("\nLibrarian:")
        print("  Email: librarian@library.com")
        print("  Password: lib123")
        print("\nStudent:")
        print("  Email: student@library.com")
        print("  Password: student123")
        print("="*50 + "\n")
        
    except Exception as e:
        db.session.rollback()
        print(f"Error creating sample data: {e}")
        sys.exit(1)

def check_requirements():
    """Check if all required packages are installed."""
    try:
        import flask
        import flask_sqlalchemy
        import flask_login
        print("All required packages are installed.")
        return True
    except ImportError as e:
        print(f"Missing required package: {e}")
        print("Please install requirements using: pip install -r requirements.txt")
        return False

def main():
    """Main function to start the application."""
    print("Academic Library Management System")
    print("=" * 40)
    
    # Check requirements
    if not check_requirements():
        sys.exit(1)
    
    # Initialize database with sample data
    with app.app_context():
        initialize_database()
    
    print("Starting the application...")
    print("Access the application at: http://localhost:5000")
    print("Press Ctrl+C to stop the server.")
    print("\n")
    
    # Start the Flask development server
    try:
        app.run(debug=True, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        print("\nShutting down the server...")
    except Exception as e:
        print(f"Error starting server: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main() 