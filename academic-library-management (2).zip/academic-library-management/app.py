from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Database Models
class User(UserMixin, db.Model):
    userID = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student')
    
    # Relationships
    transactions = db.relationship('Transaction', backref='user', lazy=True)
    fines = db.relationship('Fine', backref='user', lazy=True)
    reservations = db.relationship('Reservation', backref='user', lazy=True)
    
    def get_id(self):
        return str(self.userID)
    
    def is_student(self):
        return self.role == 'student'
    
    def is_librarian(self):
        return self.role == 'librarian'
    
    def is_admin(self):
        return self.role == 'admin'

class Book(db.Model):
    bookID = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    ISBN = db.Column(db.String(13), unique=True, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='available')
    
    # Relationships
    transactions = db.relationship('Transaction', backref='book', lazy=True)
    reservations = db.relationship('Reservation', backref='book', lazy=True)
    
    def is_available(self):
        return self.status == 'available'
    
    def is_checked_out(self):
        return self.status == 'checked_out'

class Transaction(db.Model):
    transactionID = db.Column(db.Integer, primary_key=True)
    userID = db.Column(db.Integer, db.ForeignKey('user.userID'), nullable=False)
    bookID = db.Column(db.Integer, db.ForeignKey('book.bookID'), nullable=False)
    borrowDate = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    returnDate = db.Column(db.DateTime)
    dueDate = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='active')
    
    def __init__(self, **kwargs):
        super(Transaction, self).__init__(**kwargs)
        if not self.dueDate:
            self.dueDate = self.borrowDate + timedelta(days=14)  # 2 weeks loan period
    
    def is_overdue(self):
        return self.status == 'active' and datetime.utcnow() > self.dueDate
    
    def days_overdue(self):
        if self.is_overdue():
            return (datetime.utcnow() - self.dueDate).days
        return 0

class Fine(db.Model):
    fineID = db.Column(db.Integer, primary_key=True)
    userID = db.Column(db.Integer, db.ForeignKey('user.userID'), nullable=False)
    amount = db.Column(db.Float, nullable=False, default=0.0)
    status = db.Column(db.String(20), nullable=False, default='unpaid')
    reason = db.Column(db.String(200))
    date_created = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

class Reservation(db.Model):
    reservationID = db.Column(db.Integer, primary_key=True)
    userID = db.Column(db.Integer, db.ForeignKey('user.userID'), nullable=False)
    bookID = db.Column(db.Integer, db.ForeignKey('book.bookID'), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    status = db.Column(db.String(20), nullable=False, default='active')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.is_student():
            return redirect(url_for('student_dashboard'))
        elif current_user.is_librarian():
            return redirect(url_for('librarian_dashboard'))
        elif current_user.is_admin():
            return redirect(url_for('admin_dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        role = request.form.get('role', 'student')
        
        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        user = User(name=name, email=email, password=hashed_password, role=role)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# Student Dashboard
@app.route('/student')
@login_required
def student_dashboard():
    if not current_user.is_student():
        flash('Access denied')
        return redirect(url_for('index'))
    
    # Get user's active transactions
    active_transactions = Transaction.query.filter_by(
        userID=current_user.userID, status='active'
    ).all()
    
    # Get user's reservations
    reservations = Reservation.query.filter_by(
        userID=current_user.userID, status='active'
    ).all()
    
    # Get user's fines
    fines = Fine.query.filter_by(
        userID=current_user.userID, status='unpaid'
    ).all()
    
    return render_template('student_dashboard.html', 
                         transactions=active_transactions,
                         reservations=reservations,
                         fines=fines)

# Librarian Dashboard
@app.route('/librarian')
@login_required
def librarian_dashboard():
    if not current_user.is_librarian():
        flash('Access denied')
        return redirect(url_for('index'))
    
    # Get overdue books
    overdue_transactions = Transaction.query.filter(
        Transaction.status == 'active',
        Transaction.dueDate < datetime.utcnow()
    ).all()
    
    # Get recent transactions
    recent_transactions = Transaction.query.order_by(
        Transaction.borrowDate.desc()
    ).limit(10).all()
    
    return render_template('librarian_dashboard.html',
                         overdue_transactions=overdue_transactions,
                         recent_transactions=recent_transactions)

# Admin Dashboard
@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin():
        flash('Access denied')
        return redirect(url_for('index'))
    
    # Get statistics
    total_users = User.query.count()
    total_books = Book.query.count()
    active_loans = Transaction.query.filter_by(status='active').count()
    total_fines = db.session.query(db.func.sum(Fine.amount)).filter_by(status='unpaid').scalar() or 0
    
    return render_template('admin_dashboard.html',
                         total_users=total_users,
                         total_books=total_books,
                         active_loans=active_loans,
                         total_fines=total_fines)

# Search functionality
@app.route('/search')
@login_required
def search():
    query = request.args.get('q', '')
    search_type = request.args.get('type', 'title')
    
    if query:
        if search_type == 'title':
            books = Book.query.filter(Book.title.contains(query)).all()
        elif search_type == 'author':
            books = Book.query.filter(Book.author.contains(query)).all()
        elif search_type == 'isbn':
            books = Book.query.filter(Book.ISBN.contains(query)).all()
        else:
            books = Book.query.filter(
                db.or_(
                    Book.title.contains(query),
                    Book.author.contains(query),
                    Book.ISBN.contains(query)
                )
            ).all()
    else:
        books = Book.query.all()
    
    return render_template('search.html', books=books, query=query, search_type=search_type)

# Book management
@app.route('/books')
@login_required
def manage_books():
    if not (current_user.is_librarian() or current_user.is_admin()):
        flash('Access denied')
        return redirect(url_for('index'))
    
    books = Book.query.all()
    return render_template('manage_books.html', books=books)

@app.route('/books/add', methods=['GET', 'POST'])
@login_required
def add_book():
    if not (current_user.is_librarian() or current_user.is_admin()):
        flash('Access denied')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        isbn = request.form['isbn']
        
        if Book.query.filter_by(ISBN=isbn).first():
            flash('Book with this ISBN already exists')
            return redirect(url_for('add_book'))
        
        book = Book(title=title, author=author, ISBN=isbn)
        db.session.add(book)
        db.session.commit()
        
        flash('Book added successfully')
        return redirect(url_for('manage_books'))
    
    return render_template('add_book.html')

# Checkout book
@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout_book():
    if not current_user.is_librarian():
        flash('Access denied')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        user_id = request.form['user_id']
        book_id = request.form['book_id']
        
        user = User.query.get(user_id)
        book = Book.query.get(book_id)
        
        if not user or not book:
            flash('Invalid user or book ID')
            return redirect(url_for('checkout_book'))
        
        # Check if user has overdue books
        overdue_count = Transaction.query.filter(
            Transaction.userID == user_id,
            Transaction.status == 'active',
            Transaction.dueDate < datetime.utcnow()
        ).count()
        
        if overdue_count > 0:
            flash('User has overdue books. Cannot checkout new books.')
            return redirect(url_for('checkout_book'))
        
        if not book.is_available():
            flash('Book is not available')
            return redirect(url_for('checkout_book'))
        
        # Create transaction
        transaction = Transaction(userID=user_id, bookID=book_id)
        book.status = 'checked_out'
        
        db.session.add(transaction)
        db.session.commit()
        
        flash('Book checked out successfully')
        return redirect(url_for('librarian_dashboard'))
    
    return render_template('checkout.html')

# Return book
@app.route('/return', methods=['GET', 'POST'])
@login_required
def return_book():
    if not current_user.is_librarian():
        flash('Access denied')
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        book_id = request.form['book_id']
        
        transaction = Transaction.query.filter_by(
            bookID=book_id, status='active'
        ).first()
        
        if not transaction:
            flash('No active transaction found for this book')
            return redirect(url_for('return_book'))
        
        # Calculate fine if overdue
        if transaction.is_overdue():
            fine_amount = transaction.days_overdue() * 1.0  # $1 per day
            fine = Fine(
                userID=transaction.userID,
                amount=fine_amount,
                reason=f'Overdue return: {transaction.days_overdue()} days'
            )
            db.session.add(fine)
        
        # Update transaction and book status
        transaction.returnDate = datetime.utcnow()
        transaction.status = 'completed'
        transaction.book.status = 'available'
        
        # Check if book was reserved
        reservation = Reservation.query.filter_by(
            bookID=book_id, status='active'
        ).order_by(Reservation.date).first()
        
        if reservation:
            flash(f'Book was reserved by {reservation.user.name}')
        
        db.session.commit()
        
        flash('Book returned successfully')
        return redirect(url_for('librarian_dashboard'))
    
    return render_template('return_book.html')

# Reserve book
@app.route('/reserve/<int:book_id>')
@login_required
def reserve_book(book_id):
    if not current_user.is_student():
        flash('Only students can reserve books')
        return redirect(url_for('search'))
    
    book = Book.query.get_or_404(book_id)
    
    if book.is_available():
        flash('Book is available. You can borrow it directly.')
        return redirect(url_for('search'))
    
    # Check if user already has a reservation for this book
    existing_reservation = Reservation.query.filter_by(
        userID=current_user.userID,
        bookID=book_id,
        status='active'
    ).first()
    
    if existing_reservation:
        flash('You already have a reservation for this book')
        return redirect(url_for('search'))
    
    reservation = Reservation(userID=current_user.userID, bookID=book_id)
    db.session.add(reservation)
    db.session.commit()
    
    flash('Book reserved successfully')
    return redirect(url_for('student_dashboard'))

# Reports
@app.route('/reports')
@login_required
def reports():
    if not (current_user.is_librarian() or current_user.is_admin()):
        flash('Access denied')
        return redirect(url_for('index'))
    
    report_type = request.args.get('type', 'loans')
    
    if report_type == 'loans':
        data = Transaction.query.all()
    elif report_type == 'overdue':
        data = Transaction.query.filter(
            Transaction.status == 'active',
            Transaction.dueDate < datetime.utcnow()
        ).all()
    elif report_type == 'inventory':
        data = Book.query.all()
    elif report_type == 'fines':
        data = Fine.query.all()
    else:
        data = []
    
    return render_template('reports.html', data=data, report_type=report_type)

# User management (Admin only)
@app.route('/users')
@login_required
def manage_users():
    if not current_user.is_admin():
        flash('Access denied')
        return redirect(url_for('index'))
    
    users = User.query.all()
    return render_template('manage_users.html', users=users)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Create default admin user if not exists
        admin = User.query.filter_by(email='admin@library.com').first()
        if not admin:
            admin_user = User(
                name='Admin',
                email='admin@library.com',
                password=generate_password_hash('admin123'),
                role='admin'
            )
            db.session.add(admin_user)
            
            # Create sample librarian
            librarian = User(
                name='John Librarian',
                email='librarian@library.com',
                password=generate_password_hash('lib123'),
                role='librarian'
            )
            db.session.add(librarian)
            
            # Create sample books
            sample_books = [
                Book(title='Python Programming', author='John Smith', ISBN='9781234567890'),
                Book(title='Web Development', author='Jane Doe', ISBN='9781234567891'),
                Book(title='Database Systems', author='Bob Johnson', ISBN='9781234567892'),
                Book(title='Software Engineering', author='Alice Brown', ISBN='9781234567893'),
                Book(title='Data Structures', author='Charlie Wilson', ISBN='9781234567894')
            ]
            
            for book in sample_books:
                db.session.add(book)
            
            db.session.commit()
            print("Default users and sample books created!")
    
    app.run(debug=True) 